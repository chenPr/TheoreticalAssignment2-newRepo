package cn;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class GUI{
	
	private JFrame frame;
	private JPanel p1;//屏幕
	private JPanel p2;//键盘
	private JPanel p3;//取款
	private JPanel p4;//存款
	private JTextArea textArea;
	
	public void draw(){
		
		frame = new JFrame("ATM");
		frame.setSize(500, 400);
		frame.setVisible(true);
		frame.setResizable(false);
		frame.setLayout(null);

		p1 = new JPanel();
		p1.setBounds(20,10,450, 150);
		p1.setBackground(Color.white);
		frame.add(p1);
		
		textArea = new JTextArea();
		textArea.setBounds(10, 10, 430, 130);
		p1.add(textArea);
		
		p2 = new JPanel();
		p2.setBounds(0,200,150,250);
		frame.add(p2);
		
		JButton num0 = new JButton("0");
		JButton num1 = new JButton("1");
		JButton num2 = new JButton("2");
		JButton num3 = new JButton("3");
		JButton num4 = new JButton("4");
		JButton num5 = new JButton("5");
		JButton num6 = new JButton("6");
		JButton num7 = new JButton("7");
		JButton num8 = new JButton("8");
		JButton num9 = new JButton("9");
		JButton enter = new JButton("Enter");
		p2.add(num1);
		p2.add(num2);
		p2.add(num3);
		p2.add(num4);
		p2.add(num5);
		p2.add(num6);
		p2.add(num7);
		p2.add(num8);
		p2.add(num9);
		p2.add(num0);
		p2.add(enter);
	
		num0.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				textArea.append("0");
			}
		});
		num1.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				textArea.append("1");
			}
		});
		num2.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				textArea.append("2");
			}
		});
		num3.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				textArea.append("3");
			}
		});
		num4.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				textArea.append("4");
			}
		});
		num5.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				textArea.append("5");
			}
		});
		num6.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				textArea.append("6");
			}
		});
		num7.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				textArea.append("7");
			}
		});
		num8.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				textArea.append("8");
			}
		});
		num9.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				textArea.append("9");
			}
		});
		enter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textArea.append("\n");
			}
		});
		
		p3 = new JPanel();
		p3.setBounds(200, 200, 350, 60);
		frame.add(p3);
		JLabel l1 = new JLabel("Take cash here",JLabel.CENTER);
		l1.setBounds(200, 200, 350, 60);
		l1.setBorder(BorderFactory.createEtchedBorder());
		p3.add(l1);
			
		p4 = new JPanel();
		p4.setBounds(200,280,350,60);
		frame.add(p4);
		JLabel l2 = new JLabel("Insert deposit envelope here",JLabel.CENTER);
		l2.setBounds(200,280,350,60);
		l2.setBorder(BorderFactory.createEtchedBorder());
		p4.add(l2);
		
	}

	public static void main(String[] args){
		
		GUI gui = new GUI();
		gui.draw();
	}
	
}
